library(tidyverse) # Data manipulation and visualization
library(cmdstanr)   # Interface for CmdStan binaries
library(posterior)  # Summarizing MCMC draws
library(bayesplot)  # Diagnostic plots

# Set path to CmdStan
set_cmdstan_path("C:/Users/user/.cmdstan/cmdstan-2.39.0")

# Set Execution Options
options(mc.cores = parallel::detectCores())

# -----------------------------------------------------------------------------
# 1. Load Primary Datasets
# -----------------------------------------------------------------------------
state_meta <- read.csv("nigeria_flu_state_metadata.csv")
weekly_df  <- read.csv("nigeria_flu_weekly_by_state.csv")

# Identify population column dynamically
pop_col <- intersect(c("pop_size", "population", "pop", "N"), colnames(state_meta))[1]
if (is.na(pop_col)) {
  stop("Error: Could not find a population column in state_meta. Please check colnames(state_meta).")
}

# -----------------------------------------------------------------------------
# 2. Format Metadata and Index Climate Zones
# -----------------------------------------------------------------------------
state_meta <- state_meta %>%
  arrange(state) %>%
  mutate(
    state_id    = row_number(),
    climate_idx = as.integer(factor(climate, levels = c("sahel", "savanna", "tropical"))),
    pop_vector  = .data[[pop_col]]
  )

# -----------------------------------------------------------------------------
# 3. Ensure Chronological Ordering
# -----------------------------------------------------------------------------
weekly_df <- weekly_df %>%
  arrange(state, iso_year, iso_week) %>%
  group_by(state) %>%
  mutate(time_idx = row_number()) %>%
  ungroup()

# -----------------------------------------------------------------------------
# 4. Helper Function to Construct Integer Matrices
# -----------------------------------------------------------------------------
create_matrix <- function(df, target_col) {
  mat <- df %>%
    arrange(state, time_idx) %>%
    pivot_wider(
      id_cols     = state, 
      names_from  = time_idx, 
      values_from = all_of(target_col),
      values_fill = 0
    ) %>%
    arrange(state) %>%
    select(-state) %>%
    as.matrix()
  
  storage.mode(mat) <- "integer"
  return(mat)
}

# -----------------------------------------------------------------------------
# 5. Construct Observation Matrices
# -----------------------------------------------------------------------------
cases_mat  <- create_matrix(weekly_df, "cases")
hosp_mat   <- create_matrix(weekly_df, "hospitalizations")
deaths_mat <- create_matrix(weekly_df, "deaths")

# -----------------------------------------------------------------------------
# 6. Assemble the stan_data List Dynamically
# -----------------------------------------------------------------------------
stan_data <- list(
  S            = nrow(cases_mat), 
  T            = ncol(cases_mat), 
  C            = 3, 
  
  cases_mat    = cases_mat,
  hosp_mat     = hosp_mat,
  deaths_mat   = deaths_mat,
  
  climate_zone = as.integer(state_meta$climate_idx),
  hc_access    = as.vector(scale(state_meta$hc_access)),
  state_pop    = as.numeric(state_meta$pop_vector)
)

# 7. Print structural summary
str(stan_data)

# -----------------------------------------------------------------------------
# 8. Compile Stan Model Code (OpenMP Enabled)
# -----------------------------------------------------------------------------
mod <- cmdstan_model(
  stan_file = "SEIRH.stan", 
  cpp_options = list(stan_threads = TRUE),
  force_recompile = TRUE
)

# -----------------------------------------------------------------------------
# 9. Complete Initial Value Function (Initializes 100% of Parameters)
# -----------------------------------------------------------------------------
S <- stan_data$S
T <- stan_data$T
C <- stan_data$C

# -----------------------------------------------------------------------------
# Initial Value Function (Tightened to standard realistic region)
# -----------------------------------------------------------------------------
init_fun <- function() {
  list(
    gamma        = runif(1, 1.35, 1.45),
    sigma        = runif(1, 3.40, 3.60),
    omega        = runif(1, 0.008, 0.012),
    mu_beta      = runif(C, 1.8, 2.2),
    sd_beta      = runif(1, 0.05, 0.10),
    beta_0_raw   = rnorm(S, 0, 0.05),
    A1           = rnorm(C, 0, 0.02),
    A2           = rnorm(C, 0, 0.02),
    dev_beta     = matrix(rnorm(S * T, 0, 0.005), nrow = S, ncol = T),
    sigma_beta   = runif(1, 0.01, 0.03),
    mu_rho_logit = runif(1, -2.1, -1.9),
    sd_rho_logit = runif(1, 0.02, 0.05),
    rho_raw      = rnorm(S, 0, 0.05),
    alpha_hosp   = runif(1, -3.6, -3.4),
    beta_hosp    = runif(1, -0.05, 0.05),
    alpha_cfr    = runif(1, -2.1, -1.9),
    beta_cfr     = runif(1, -0.05, 0.05),
    phi_cases    = runif(S, 10, 20),
    phi_hosp     = runif(1, 10, 20),
    phi_deaths   = runif(1, 10, 20),
    log_i0       = runif(S, -5.8, -5.2)
  )
}


fit <- mod$sample(
  data              = stan_data,
  init              = init_fun,
  seed              = 2026,
  chains            = 4,
  parallel_chains   = 2,        # Run 2 chains at a time so your CPU doesn't choke
  threads_per_chain = 2,        # Use 2 CPU threads per chain to speed up reduce_sum
  iter_warmup       = 500,
  iter_sampling     = 500,
  adapt_delta       = 0.88,     # Restores normal step size
  max_treedepth     = 10      # Caps max tree depth back to 1024 steps
)



# ==============================================================================
# 3. RELOAD IN A NEW SESSION (Laptop Restart / Fresh Environment)
# ==============================================================================
library(tidyverse)
library(cmdstanr)

setwd("C:/Users/user/Documents/Documents_TUT/R_code1/Maepims/North_His_Calib_Basel/")

# Load both files safely
if (file.exists("stan_fit_results.rds") && file.exists("stan_data.rds")) {
  fit       <- readRDS("stan_fit_results.rds")
  stan_data <- readRDS("stan_data.rds")
  cat("✔ Successfully loaded model fit and stan_data!\n")
} else {
  stop("Error: RDS files not found in the current working directory.")
}



# Define exact names of Northern states + FCT (20 units total)
northern_fct_names <- c(
  "Adamawa", "Bauchi", "Borno", "Gombe", "Taraba", "Yobe",          # North-East (6)
  "Jigawa", "Kaduna", "Kano", "Katsina", "Kebbi", "Sokoto", "Zamfara", # North-West (7)
  "Benue", "Kogi", "Kwara", "Nasarawa", "Niger", "Plateau", "FCT"    # North-Central (7)
)

# Filter state metadata to capture Northern states + FCT and their original indices (s_orig)
state_meta_north <- state_meta %>%
  mutate(s_orig = row_number()) %>%
  filter(state %in% northern_fct_names)

# Base grid for Northern states x T weeks
base_grid <- expand.grid(s_idx = 1:nrow(state_meta_north), t = 1:stan_data$T) %>%
  mutate(
    s = state_meta_north$s_idx[s_idx],
    s_orig = state_meta_north$s_orig[s_idx],
    state_name = state_meta_north$state[s_idx]
  )

# ==============================================================================
# 1. EXTRACT & SAVE PROBABILISTIC TARGETS (Northern States + FCT Only)
# ==============================================================================
cat("Extracting posterior predictions for Northern States and FCT...\n")

extract_predictions <- function(param_prefix, obs_matrix, stream_name) {
  draws_mat <- fit$draws(param_prefix, format = "draws_matrix")
  param_names <- sprintf("%s[%d,%d]", param_prefix, base_grid$s_orig, base_grid$t)
  
  obs_vec <- mapply(function(s, t) obs_matrix[s, t], base_grid$s_orig, base_grid$t)
  
  df <- base_grid %>%
    mutate(
      stream   = stream_name,
      observed = obs_vec,
      mean     = apply(draws_mat[, param_names], 2, mean),
      median   = apply(draws_mat[, param_names], 2, median),
      q2.5     = apply(draws_mat[, param_names], 2, quantile, probs = 0.025),
      q5       = apply(draws_mat[, param_names], 2, quantile, probs = 0.05),
      q25      = apply(draws_mat[, param_names], 2, quantile, probs = 0.25),
      q75      = apply(draws_mat[, param_names], 2, quantile, probs = 0.75),
      q95      = apply(draws_mat[, param_names], 2, quantile, probs = 0.95),
      q97.5    = apply(draws_mat[, param_names], 2, quantile, probs = 0.975)
    ) %>%
    select(-s_idx, -s_orig)
  return(df)
}

# Process all 3 outcome streams
cases_summary <- extract_predictions("cases_rep", stan_data$cases_mat, "Cases")
hosp_summary  <- extract_predictions("hosp_rep",  stan_data$hosp_mat,  "Hospitalizations")
death_summary <- extract_predictions("deaths_rep", stan_data$deaths_mat, "Deaths")

# Combine into a single forecast summary table
pred_summary_all <- bind_rows(cases_summary, hosp_summary, death_summary)

# Save forecast dataset to CSV
write.csv(pred_summary_all, "fitting_data_summary_north.csv", row.names = FALSE)
cat("✔ Saved 'fitting_data_summary_north.csv'\n")

# Print summary of key parameters
print(fit$summary(c("gamma", "sigma", "omega", "rho", "alpha_hosp", "beta_hosp", 
                    "alpha_cfr", "beta_cfr")))

# Extract all posterior draws once for diagnostics
draws_all <- fit$draws()

# Summarize MCMC diagnostics across all parameters
fit_summary <- fit$summary()

high_rhat <- fit_summary %>%
  filter(rhat > 1.05) %>%
  select(variable, mean, sd, rhat, ess_bulk, ess_tail) %>%
  arrange(desc(rhat))

cat("====================================================\n")
cat("Total parameters with Rhat > 1.05:", nrow(high_rhat), "\n")
cat("====================================================\n\n")

if (nrow(high_rhat) > 0) {
  print(high_rhat, n = 50)
} else {
  cat("✔ All parameters have converged successfully (Rhat <= 1.05)!\n")
}

# ==============================================================================
# 2. EXTRACT & SAVE FULL PARAMETER SUMMARY TABLE
# ==============================================================================
cat("Extracting summary for all estimated parameters...\n")

all_param_summary <- fit$summary(
  variables = NULL,
  "mean", "sd", "median", "mad",
  ~quantile(.x, probs = c(0.025, 0.05, 0.25, 0.50, 0.75, 0.95, 0.975)),
  "rhat", "ess_bulk", "ess_tail"
)

all_param_summary <- all_param_summary %>%
  mutate(
    mcse_mean = sd / sqrt(ess_bulk),
    .after = sd
  )

write.csv(all_param_summary, "stan_all_parameters_posterior_summary_north.csv", row.names = FALSE)
cat("✔ Successfully saved full posterior summary\n")

# ==============================================================================
# 3. HELPER FUNCTIONS FOR MULTI-PAGE DIAGNOSTICS
# ==============================================================================

plot_trace_pages <- function(draws_obj, param_list, title_prefix, per_page = 6) {
  n_total <- length(param_list)
  n_pages <- ceiling(n_total / per_page)
  
  for (i in 1:n_pages) {
    idx_start  <- (i - 1) * per_page + 1
    idx_end    <- min(i * per_page, n_total)
    sub_params <- param_list[idx_start:idx_end]
    
    p <- mcmc_trace(draws_obj, pars = sub_params) +
      labs(title = paste0(title_prefix, " (Page ", i, " of ", n_pages, ")")) +
      theme_bw(base_size = 11)
    
    print(p)
  }
}

plot_dens_pages <- function(draws_obj, param_list, title_prefix, per_page = 6) {
  n_total <- length(param_list)
  n_pages <- ceiling(n_total / per_page)
  
  for (i in 1:n_pages) {
    idx_start  <- (i - 1) * per_page + 1
    idx_end    <- min(i * per_page, n_total)
    sub_params <- param_list[idx_start:idx_end]
    
    p <- mcmc_dens_overlay(draws_obj, pars = sub_params) +
      labs(title = paste0(title_prefix, " (Page ", i, " of ", n_pages, ")")) +
      theme_bw(base_size = 11)
    
    print(p)
  }
}

# ==============================================================================
# 4. CONSTRUCT DATA & GENERATE FIT TRAJECTORIES PDF (North + FCT Only)
# ==============================================================================
cat("Constructing multi-stream posterior predictive trajectories for Northern states + FCT...\n")

extract_stream_summary <- function(fit_obj, param_prefix, obs_matrix, stream_name) {
  draws_mat <- fit_obj$draws(param_prefix, format = "draws_matrix")
  param_names <- sprintf("%s[%d,%d]", param_prefix, base_grid$s_orig, base_grid$t)
  
  obs_vec <- mapply(function(s, t) obs_matrix[s, t], base_grid$s_orig, base_grid$t)
  
  df <- base_grid %>%
    mutate(
      stream   = stream_name,
      observed = obs_vec,
      median   = apply(draws_mat[, param_names], 2, median),
      q5       = apply(draws_mat[, param_names], 2, quantile, probs = 0.05),
      q95      = apply(draws_mat[, param_names], 2, quantile, probs = 0.95)
    ) %>%
    select(-s_idx, -s_orig)
  return(df)
}

cases_df <- extract_stream_summary(fit, "cases_rep", stan_data$cases_mat, "Cases")
hosp_df  <- extract_stream_summary(fit, "hosp_rep",  stan_data$hosp_mat,  "Hospitalizations")
death_df <- extract_stream_summary(fit, "deaths_rep", stan_data$deaths_mat, "Deaths")

pred_summary_all <- bind_rows(cases_df, hosp_df, death_df) %>%
  mutate(stream = factor(stream, levels = c("Cases", "Hospitalizations", "Deaths")))

# PDF 1: Multi-Stream Trajectories
streams <- c("Cases", "Hospitalizations", "Deaths")
colors  <- c("Cases" = "#1F78B4", "Hospitalizations" = "#E31A1C", "Deaths" = "#33A02C")

all_states <- unique(pred_summary_all$state_name)
states_per_page <- 4
n_states <- length(all_states)
n_pages  <- ceiling(n_states / states_per_page)

for (str in streams) {
  pdf_name <- paste0("SEIRH_Northern_FCT_", str, "_Fits.pdf")
  df_stream <- pred_summary_all %>% filter(stream == str)
  
  tryCatch({
    pdf(pdf_name, width = 11, height = 12)
    
    for (i in 1:n_pages) {
      idx_start <- (i - 1) * states_per_page + 1
      idx_end   <- min(i * states_per_page, n_states)
      page_states <- all_states[idx_start:idx_end]
      
      df_page <- df_stream %>% filter(state_name %in% page_states)
      
      p <- ggplot(df_page, aes(x = t)) +
        geom_ribbon(aes(ymin = pmax(0, q5), ymax = q95), fill = colors[str], alpha = 0.3) +
        geom_line(aes(y = median), color = colors[str], linewidth = 0.8) +
        geom_point(aes(y = observed), color = "black", size = 0.8, alpha = 0.6) +
        facet_wrap(~ state_name, ncol = 1, scales = "free_y") +
        scale_y_continuous(limits = c(0, NA)) +
        labs(
          title = paste0("HMB-ML Model Fit (North + FCT): Weekly ", str, " (Page ", i, " of ", n_pages, ")"),
          subtitle = "Observed Surveillance Data vs Posterior Median & 90% CrI",
          x = "Epidemiological Week",
          y = paste0("Weekly ", str, " Count")
        ) +
        theme_bw(base_size = 11) +
        theme(
          strip.background = element_rect(fill = "grey90"),
          strip.text = element_text(face = "bold", size = 10),
          panel.grid.minor = element_blank()
        )
      
      print(p)
    }
    
  }, finally = {
    if (dev.cur() > 1) dev.off()
  })
  
  cat("Successfully generated:", pdf_name, "\n")
}

# ==============================================================================
# 5. DEFINE PARAMETER GROUPS & GENERATE TRACE PLOTS PDF (Subset to North Indices)
# ==============================================================================

global_params   <- c("gamma", "sigma", "omega", "sigma_beta", "mu_rho_logit", "sd_rho_logit", "sd_beta")
climate_params  <- c("mu_beta[1]", "mu_beta[2]", "mu_beta[3]", 
                     "A1[1]", "A1[2]", "A1[3]", 
                     "A2[1]", "A2[2]", "A2[3]")
clinical_params <- c("alpha_hosp", "beta_hosp", "alpha_cfr", "beta_cfr", "phi_hosp", "phi_deaths")
core_params     <- c(global_params, climate_params, clinical_params)

north_indices <- state_meta_north$s_orig

rho_params   <- paste0("rho[", north_indices, "]")
beta0_params <- paste0("beta_0[", north_indices, "]")
eta_params   <- paste0("eta[", north_indices, "]")
cfr_params   <- paste0("CFR[", north_indices, "]")
phi_c_params <- paste0("phi_cases[", north_indices, "]")

# PDF 2: Trace Plots
pdf_trace <- "diagnostics_trace_plots_north.pdf"
tryCatch({
  pdf(pdf_trace, width = 11, height = 8.5)
  
  plot_trace_pages(draws_all, core_params, "Trace Plots: Core & Global Parameters", per_page = 6)
  plot_trace_pages(draws_all, rho_params, "Trace Plots: State Reporting Rates (rho) [North]", per_page = 6)
  plot_trace_pages(draws_all, beta0_params, "Trace Plots: State Baseline Transmission (beta_0) [North]", per_page = 6)
  plot_trace_pages(draws_all, eta_params, "Trace Plots: State Hospitalization Rates (eta) [North]", per_page = 6)
  plot_trace_pages(draws_all, cfr_params, "Trace Plots: State Case Fatality Rates (CFR) [North]", per_page = 6)
  plot_trace_pages(draws_all, phi_c_params, "Trace Plots: Case Dispersion (phi_cases) [North]", per_page = 6)
  
}, finally = {
  dev.off()
})
cat("Saved:", pdf_trace, "\n")

# ==============================================================================
# 6. MULTI-PAGE DENSITY PLOTS PDF
# ==============================================================================

pdf_dens <- "diagnostics_density_plots_north.pdf"
tryCatch({
  pdf(pdf_dens, width = 11, height = 8.5)
  
  plot_dens_pages(draws_all, core_params, "Posterior Densities: Core Parameters", per_page = 6)
  plot_dens_pages(draws_all, rho_params, "Posterior Densities: State Reporting Rates (rho) [North]", per_page = 6)
  plot_dens_pages(draws_all, beta0_params, "Posterior Densities: State Transmission (beta_0) [North]", per_page = 6)
  plot_dens_pages(draws_all, eta_params, "Posterior Densities: State Hospitalization (eta) [North]", per_page = 6)
  plot_dens_pages(draws_all, cfr_params, "Posterior Densities: State CFR [North]", per_page = 6)
  
}, finally = {
  dev.off()
})
cat("Saved:", pdf_dens, "\n")

# ==============================================================================
# 7. STRUCTURED PAIRS PLOTS PDF
# ==============================================================================

pdf_pairs <- "diagnostics_pairs_plots_north.pdf"
tryCatch({
  pdf(pdf_pairs, width = 12, height = 12)
  
  print(mcmc_pairs(draws_all, pars = c("gamma", "sigma", "omega", "sigma_beta"), off_diag_args = list(size = 0.8, alpha = 0.3)))
  print(mcmc_pairs(draws_all, pars = c("mu_beta[1]", "mu_beta[2]", "mu_beta[3]", "mu_rho_logit", "sd_rho_logit", "sd_beta"), off_diag_args = list(size = 0.8, alpha = 0.3)))
  print(mcmc_pairs(draws_all, pars = c("alpha_hosp", "beta_hosp", "alpha_cfr", "beta_cfr", "phi_hosp", "phi_deaths"), off_diag_args = list(size = 0.8, alpha = 0.3)))
  
  n3_idx <- north_indices[1:min(3, length(north_indices))]
  print(mcmc_pairs(draws_all, pars = c(paste0("beta_0[", n3_idx, "]"), paste0("rho[", n3_idx, "]")), off_diag_args = list(size = 0.8, alpha = 0.3)))
  
}, finally = {
  dev.off()
})
cat("Saved:", pdf_pairs, "\n")

while (dev.cur() > 1) dev.off()




# ==============================================================================
# 1. STREAM-SPECIFIC EXTRACTION & INDIVIDUAL PDF PLOTS (Cases, Hosp, Deaths)
# ==============================================================================
cat("Extracting and generating individual stream plots for Northern region...\n")

streams <- c("Cases", "Hospitalizations", "Deaths")
stream_prefixes <- c("cases_rep", "hosp_rep", "deaths_rep")
stream_matrices <- list(stan_data$cases_mat, stan_data$hosp_mat, stan_data$deaths_mat)
colors <- c("Cases" = "#1F78B4", "Hospitalizations" = "#E31A1C", "Deaths" = "#33A02C")

all_states <- unique(base_grid$state_name)
states_per_page <- 4
n_states <- length(all_states)
n_pages <- ceiling(n_states / states_per_page)

for (idx in seq_along(streams)) {
  str_name <- streams[idx]
  pref <- stream_prefixes[idx]
  obs_mat <- stream_matrices[[idx]]
  
  # Extract predictions for this specific stream
  draws_mat <- fit$draws(pref, format = "draws_matrix")
  param_names <- sprintf("%s[%d,%d]", pref, base_grid$s_orig, base_grid$t)
  obs_vec <- mapply(function(s, t) obs_mat[s, t], base_grid$s_orig, base_grid$t)
  
  df_stream <- base_grid %>%
    mutate(
      stream   = str_name,
      observed = obs_vec,
      median   = apply(draws_mat[, param_names], 2, median),
      q5       = apply(draws_mat[, param_names], 2, quantile, probs = 0.05),
      q95      = apply(draws_mat[, param_names], 2, quantile, probs = 0.95)
    ) %>%
    select(-s_idx, -s_orig)
  
  # Save individual stream summary CSV
  write.csv(df_stream, paste0("maepims_fitting_", tolower(str_name), "_summary_north.csv"), row.names = FALSE)
  
  # Generate individual multi-page PDF for the stream
  pdf_name <- paste0("SEIRH_Northern_FCT_", str_name, "_Fits.pdf")
  tryCatch({
    pdf(pdf_name, width = 11, height = 12)
    
    for (i in 1:n_pages) {
      idx_start <- (i - 1) * states_per_page + 1
      idx_end <- min(i * states_per_page, n_states)
      page_states <- all_states[idx_start:idx_end]
      
      df_page <- df_stream %>% filter(state_name %in% page_states)
      
      p <- ggplot(df_page, aes(x = t)) +
        geom_ribbon(aes(ymin = pmax(0, q5), ymax = q95), fill = colors[str_name], alpha = 0.3) +
        geom_line(aes(y = median), color = colors[str_name], linewidth = 0.8) +
        geom_point(aes(y = observed), color = "black", size = 0.8, alpha = 0.6) +
        facet_wrap(~ state_name, ncol = 1, scales = "free_y") +
        scale_y_continuous(limits = c(0, NA)) +
        labs(
          title = paste0("HMB-ML Model Fit (North + FCT): Weekly ", str_name, " (Page ", i, " of ", n_pages, ")"),
          subtitle = "Observed Surveillance Data vs Posterior Median & 90% CrI",
          x = "Epidemiological Week",
          y = paste0("Weekly ", str_name, " Count")
        ) +
        theme_bw(base_size = 11) +
        theme(
          strip.background = element_rect(fill = "grey90"),
          strip.text = element_text(face = "bold", size = 10),
          panel.grid.minor = element_blank()
        )
      
      print(p)
    }
  }, finally = {
    if (dev.cur() > 1) dev.off()
  })
  cat("✔ Saved individual PDF and CSV for:", str_name, "\n")
}

# ==============================================================================
# 2. COMPARISON PLOTS FOR REPRESENTATIVE STATES (NW, NE, NC) ACROSS 3 STREAMS
# ==============================================================================
cat("Generating comparative representative state plots...\n")

# Combine all streams into one data frame using existing variables
extract_stream_summary_all <- function(fit_obj, param_prefix, obs_matrix, stream_name) {
  draws_mat <- fit_obj$draws(param_prefix, format = "draws_matrix")
  param_names <- sprintf("%s[%d,%d]", param_prefix, base_grid$s_orig, base_grid$t)
  obs_vec <- mapply(function(s, t) obs_matrix[s, t], base_grid$s_orig, base_grid$t)
  
  base_grid %>%
    mutate(
      stream   = stream_name,
      observed = obs_vec,
      median   = apply(draws_mat[, param_names], 2, median),
      q5       = apply(draws_mat[, param_names], 2, quantile, probs = 0.05),
      q95      = apply(draws_mat[, param_names], 2, quantile, probs = 0.95)
    ) %>%
    select(-s_idx, -s_orig)
}

cases_df <- extract_stream_summary_all(fit, "cases_rep", stan_data$cases_mat, "Cases")
hosp_df  <- extract_stream_summary_all(fit, "hosp_rep",  stan_data$hosp_mat,  "Hospitalizations")
death_df <- extract_stream_summary_all(fit, "deaths_rep", stan_data$deaths_mat, "Deaths")

pred_summary_all_streams <- bind_rows(cases_df, hosp_df, death_df) %>%
  mutate(stream = factor(stream, levels = c("Cases", "Hospitalizations", "Deaths")))

# Select 1 representative state from each region
rep_nw <- "Kano"       # North-West representative
rep_ne <- "Borno"      # North-East representative
rep_nc <- "Kwara"     # North-Central / FCT representative (adjust if preferred)

# Figure 1: Panel comparing North-West and North-East across 3 streams
pdf("SEIRH_Comparison_NW_NE.pdf", width = 10, height = 8)
df_fig1 <- pred_summary_all_streams %>% filter(state_name %in% c(rep_nw, rep_ne))

p_fig1 <- ggplot(df_fig1, aes(x = t, color = stream, fill = stream)) +
  geom_ribbon(aes(ymin = pmax(0, q5), ymax = q95), alpha = 0.2, color = NA) +
  geom_line(aes(y = median), linewidth = 0.7) +
  geom_point(aes(y = observed), size = 0.6, alpha = 0.5) +
  facet_grid(stream ~ state_name, scales = "free_y") +
  scale_color_manual(values = colors) +
  scale_fill_manual(values = colors) +
  labs(
    title = paste0("Comparative Fit: North-West (", rep_nw, ") vs North-East (", rep_ne, ")"),
    subtitle = "Posterior Median & 90% CrI vs Observed Data across Surveillance Streams",
    x = "Epidemiological Week",
    y = "Count"
  ) +
  theme_bw(base_size = 11) +
  theme(legend.position = "bottom", strip.background = element_rect(fill = "grey90"))

print(p_fig1)
dev.off()

# Figure 2: Panel for the 3rd region (North-Central / FCT representative)
pdf("SEIRH_Comparison_NC.pdf", width = 10, height = 7)
df_fig2 <- pred_summary_all_streams %>% filter(state_name == rep_nc)

p_fig2 <- ggplot(df_fig2, aes(x = t, color = stream, fill = stream)) +
  geom_ribbon(aes(ymin = pmax(0, q5), ymax = q95), alpha = 0.2, color = NA) +
  geom_line(aes(y = median), linewidth = 0.8) +
  geom_point(aes(y = observed), size = 0.8, alpha = 0.6) +
  facet_wrap(~ stream, ncol = 1, scales = "free_y") +
  scale_color_manual(values = colors) +
  scale_fill_manual(values = colors) +
  labs(
    title = paste0("Comparative Fit: North-Central Region Representative (", rep_nc, ")"),
    subtitle = "Posterior Median & 90% CrI vs Observed Data across Surveillance Streams",
    x = "Epidemiological Week",
    y = "Count"
  ) +
  theme_bw(base_size = 11) +
  theme(legend.position = "bottom", strip.background = element_rect(fill = "grey90"))

print(p_fig2)
dev.off()

cat("✔ Successfully generated comparison PDFs: 'SEIRH_Comparison_NW_NE.pdf' and 'SEIRH_Comparison_NC.pdf'\n")



# ==============================================================================
# REGIONAL AGGREGATION & PLOTTING (Summing across all Northern States + FCT)
# ==============================================================================
cat("Aggregating posterior predictions for the entire Northern Region...\n")

# Extract full posterior matrix for each stream across all 20 northern units and time steps
aggregate_regional_stream <- function(fit_obj, param_prefix, obs_matrix, stream_name) {
  draws_mat <- fit_obj$draws(param_prefix, format = "draws_matrix") # draws x parameters
  
  # For each time step t, we sum the parameter draws across all s in base_grid
  time_steps <- unique(base_grid$t)
  
  regional_df <- map_dfr(time_steps, function(wk) {
    # Find matching column names for week wk across all northern states (s_orig)
    matching_cols <- sprintf("%s[%d,%d]", param_prefix, base_grid$s_orig[base_grid$t == wk], wk)
    
    # Sum draws across all northern states for each MCMC iteration
    draws_summed <- rowSums(draws_mat[, matching_cols, drop = FALSE])
    
    # Sum observed data for this week across all northern states
    obs_summed <- sum(obs_matrix[base_grid$s_orig[base_grid$t == wk], wk])
    
    tibble(
      t        = wk,
      stream   = stream_name,
      observed = obs_summed,
      mean     = mean(draws_summed),
      median   = median(draws_summed),
      q5       = quantile(draws_summed, probs = 0.05),
      q95      = quantile(draws_summed, probs = 0.95)
    )
  })
  
  return(regional_df)
}

# Aggregate all three streams for the Northern region
reg_cases <- aggregate_regional_stream(fit, "cases_rep", stan_data$cases_mat, "Cases")
reg_hosp  <- aggregate_regional_stream(fit, "hosp_rep",  stan_data$hosp_mat,  "Hospitalizations")
reg_death <- aggregate_regional_stream(fit, "deaths_rep", stan_data$deaths_mat, "Deaths")

pred_summary_regional <- bind_rows(reg_cases, reg_hosp, reg_death) %>%
  mutate(stream = factor(stream, levels = c("Cases", "Hospitalizations", "Deaths")))

# Save regional aggregated summary
write.csv(pred_summary_regional, "maepims_fitting_northern_region_aggregated_summary.csv", row.names = FALSE)
cat("✔ Saved 'maepims_fitting_northern_region_aggregated_summary.csv'\n")

# Generate 3-stream regional aggregated plot PDF
pdf("SEIRH_Northern_Region_Aggregated_Fits.pdf", width = 10, height = 8)

p_regional <- ggplot(pred_summary_regional, aes(x = t)) +
  geom_ribbon(aes(ymin = pmax(0, q5), ymax = q95, fill = stream), alpha = 0.3) +
  geom_line(aes(y = median, color = stream), linewidth = 0.9) +
  geom_point(aes(y = observed), color = "black", size = 1.0, alpha = 0.6) +
  facet_wrap(~ stream, ncol = 1, scales = "free_y") +
  scale_color_manual(values = colors) +
  scale_fill_manual(values = colors) +
  labs(
    title = "HMB-ML Model Fit: Total Aggregated Northern Region & FCT",
    subtitle = "Summed Observed Data vs Posterior Median & 90% CrI across Surveillance Streams",
    x = "Epidemiological Week",
    y = "Total Weekly Count"
  ) +
  theme_bw(base_size = 12) +
  theme(
    legend.position = "none",
    strip.background = element_rect(fill = "grey90"),
    strip.text = element_text(face = "bold", size = 11),
    panel.grid.minor = element_blank()
  )

print(p_regional)
dev.off()

cat("✔ Successfully generated regional aggregated plot: 'SEIRH_Northern_Region_Aggregated_Fits.pdf'\n")



# ==============================================================================
# CLIMATE ZONE AGGREGATION & MULTI-PANEL PLOTTING (Using existing stan_data$climate_zone)
# ==============================================================================
cat("Aggregating posterior predictions by climate zone...\n")

# Map climate zones directly using existing base_grid and stan_data$climate_zone
base_grid_zone <- base_grid %>%
  mutate(
    zone_label = case_when(
      stan_data$climate_zone[s_idx] == 1 ~ "Sahel Zone",
      TRUE ~ "Savannah Zone"
    )
  )

aggregate_zone_stream <- function(fit_obj, param_prefix, obs_matrix, stream_name) {
  draws_mat <- fit_obj$draws(param_prefix, format = "draws_matrix")
  time_steps <- unique(base_grid_zone$t)
  zones <- unique(base_grid_zone$zone_label)
  
  map_dfr(zones, function(zn) {
    zone_s_orig <- unique(base_grid_zone$s_orig[base_grid_zone$zone_label == zn])
    
    map_dfr(time_steps, function(wk) {
      matching_cols <- unlist(lapply(zone_s_orig, function(s) sprintf("%s[%d,%d]", param_prefix, s, wk)))
      
      draws_summed <- rowSums(draws_mat[, matching_cols, drop = FALSE])
      obs_summed <- sum(obs_matrix[zone_s_orig, wk])
      
      tibble(
        t          = wk,
        stream     = stream_name,
        zone_label = zn,
        observed   = obs_summed,
        median     = median(draws_summed),
        q5         = quantile(draws_summed, probs = 0.05),
        q95        = quantile(draws_summed, probs = 0.95)
      )
    })
  })
}

# Aggregate all three streams by climate zone
zone_cases <- aggregate_zone_stream(fit, "cases_rep", stan_data$cases_mat, "Cases")
zone_hosp  <- aggregate_zone_stream(fit, "hosp_rep",  stan_data$hosp_mat,  "Hospitalizations")
zone_death <- aggregate_zone_stream(fit, "deaths_rep", stan_data$deaths_mat, "Deaths")

pred_summary_zones <- bind_rows(zone_cases, zone_hosp, zone_death) %>%
  mutate(stream = factor(stream, levels = c("Cases", "Hospitalizations", "Deaths")))

# Save summary
write.csv(pred_summary_zones, "maepims_fitting_climate_zones_summary.csv", row.names = FALSE)
cat("✔ Saved 'maepims_fitting_climate_zones_summary.csv'\n")

# Generate combined multi-panel plot PDF on the same panel
pdf("SEIRH_Climate_Zones_Comparison_Fits.pdf", width = 11, height = 8.5)

p_zones <- ggplot(pred_summary_zones, aes(x = t, color = stream, fill = stream)) +
  geom_ribbon(aes(ymin = pmax(0, q5), ymax = q95), alpha = 0.2, color = NA) +
  geom_line(aes(y = median), linewidth = 0.8) +
  geom_point(aes(y = observed), size = 0.7, alpha = 0.6) +
  facet_grid(stream ~ zone_label, scales = "free_y") +
  scale_color_manual(values = colors) +
  scale_fill_manual(values = colors) +
  labs(
    title = "HMB-ML Model Fit: Sahel vs. Savannah Climatic Zones",
    subtitle = "Aggregated Surveillance Streams vs Posterior Median & 90% CrI",
    x = "Epidemiological Week",
    y = "Aggregated Weekly Count"
  ) +
  theme_bw(base_size = 11) +
  theme(
    legend.position = "bottom",
    strip.background = element_rect(fill = "grey90"),
    strip.text = element_text(face = "bold", size = 10),
    panel.grid.minor = element_blank()
  )

print(p_zones)
dev.off()

cat("✔ Successfully generated climate zone comparison PDF: 'SEIRH_Climate_Zones_Comparison_Fits.pdf'\n")







# ==============================================================================
# QUANTIFYING & VISUALIZING FOURIER HARMONICS (A1, A2) & BASELINE TRANSMISSION (beta_0)
# ==============================================================================
library(tidyverse)
library(posterior)

cat("Extracting posterior draws for Fourier amplitudes and baseline transmission...\n")

# 1. Extract Posterior Draws for A1, A2, and beta_0
draws_df <- fit$draws(format = "draws_df")

# Number of climate zones (C) and northern states (S_north)
C <- stan_data$C
num_north_states <- nrow(state_meta_north)

# ------------------------------------------------------------------------------
# A. SUMMARIZE & PLOT CLIMATE-ZONE HARMONIC AMPLITUDES (A1 & A2)
# ------------------------------------------------------------------------------
cat("Summarizing climate-zone harmonic amplitudes (A1, A2)...\n")

# Extract summary table directly for A1 and A2 across climate zones
amp_summary <- fit$summary(
  variables = c(sprintf("A1[%d]", 1:C), sprintf("A2[%d]", 1:C)),
  "mean", "median", 
  ~quantile(.x, probs = c(0.025, 0.975))
) %>%
  rename(q2.5 = `2.5%`, q97.5 = `97.5%`) %>%
  mutate(
    parameter = sub("\\[.*\\]", "", variable),
    zone_id   = as.integer(sub(".*\\[([0-9]+)\\]", "\\1", variable)),
    zone_label = case_when(
      zone_id == 1 ~ "Sahel Zone",
      TRUE ~ paste0("Savannah Zone (", zone_id, ")")
    )
  )

# Save summary table
write.csv(amp_summary, "maepims_harmonic_amplitudes_summary.csv", row.names = FALSE)
cat("✔ Saved 'maepims_harmonic_amplitudes_summary.csv'\n")

# Plot 1: Forest/Point-Interval Plot for Harmonic Amplitudes
pdf("SEIRH_Harmonic_Amplitudes_Comparison.pdf", width = 8, height = 6)

p_amp <- ggplot(amp_summary, aes(x = zone_label, y = median, color = parameter)) +
  geom_point(position = position_dodge(width = 0.3), size = 3) +
  geom_errorbar(aes(ymin = q2.5, ymax = q97.5), position = position_dodge(width = 0.3), width = 0.15, linewidth = 0.8) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "grey50") +
  scale_color_manual(values = c("A1" = "#1F78B4", "A2" = "#E31A1C"), 
                     labels = c("A1" = "Annual Amplitude (A1)", "A2" = "Semi-Annual Amplitude (A2)")) +
  labs(
    title = "Climate-Zone-Specific Fourier Harmonic Amplitudes",
    subtitle = "Posterior Median & 95% Credible Intervals",
    x = "Climate Zone",
    y = "Amplitude Value",
    color = "Harmonic Component"
  ) +
  theme_bw(base_size = 12) +
  theme(legend.position = "bottom", panel.grid.minor = element_blank())

print(p_amp)
dev.off()
cat("✔ Saved 'SEIRH_Harmonic_Amplitudes_Comparison.pdf'\n")


# ------------------------------------------------------------------------------
# B. RECONSTRUCT & PLOT SEASONAL FORCING CURVES OVER 52 WEEKS
# ------------------------------------------------------------------------------
cat("Reconstructing seasonal forcing curves across 52 weeks...\n")

weeks_seq <- 1:52
twopi_52  <- 2.0 * pi / 52.0
fourpi_52 <- 4.0 * pi / 52.0

# Compute reconstructed seasonal term: 1.0 + A1*sin(...) + A2*cos(...) for each MCMC draw
seasonal_forcing_df <- map_dfr(1:C, function(z) {
  # Extract draws for A1[z] and A2[z]
  col_a1 <- sprintf("A1[%d]", z)
  col_a2 <- sprintf("A2[%d]", z)
  
  a1_draws <- draws_df[[col_a1]]
  a2_draws <- draws_df[[col_a2]]
  
  map_dfr(weeks_seq, function(wk) {
    # Calculate seasonal multiplier vector across all posterior draws
    mult_draws <- 1.0 + a1_draws * sin(twopi_52 * wk) + a2_draws * cos(fourpi_52 * wk)
    
    tibble(
      week   = wk,
      zone_id = z,
      zone_label = case_when(z == 1 ~ "Sahel Zone", TRUE ~ paste0("Savannah Zone (", z, ")")),
      median = median(mult_draws),
      q2.5   = quantile(mult_draws, 0.025),
      q97.5  = quantile(mult_draws, 0.975)
    )
  })
})

# Plot 2: Reconstructed Seasonality Curves
pdf("SEIRH_Reconstructed_Seasonality_Curves.pdf", width = 10, height = 6)

p_seas <- ggplot(seasonal_forcing_df, aes(x = week, y = median, color = zone_label, fill = zone_label)) +
  geom_ribbon(aes(ymin = q2.5, ymax = q97.5), alpha = 0.2, color = NA) +
  geom_line(linewidth = 1) +
  geom_hline(yintercept = 1.0, linetype = "dashed", color = "grey50") +
  labs(
    title = "Reconstructed Climate-Zone Seasonal Forcing Multiplier",
    subtitle = "Annual Transmission Multiplier (Posterior Median & 95% CrI)",
    x = "Epidemiological Week",
    y = "Seasonal Forcing Multiplier (beta_t / beta_0)",
    color = "Climate Zone",
    fill = "Climate Zone"
  ) +
  theme_bw(base_size = 12) +
  theme(legend.position = "bottom", panel.grid.minor = element_blank())

print(p_seas)
dev.off()
cat("✔ Saved 'SEIRH_Reconstructed_Seasonality_Curves.pdf'\n")


# ------------------------------------------------------------------------------
# C. QUANTIFY & PLOT SPATIAL BASELINE TRANSMISSION RATES (beta_0,s)
# ------------------------------------------------------------------------------
cat("Quantifying spatial baseline transmission rates (beta_0)...\n")

# Map northern state indices (s_orig) to extract beta_0 summary
beta0_vars <- sprintf("beta_0[%d]", state_meta_north$s_orig)

beta0_summary <- fit$summary(
  variables = beta0_vars,
  "mean", "median",
  ~quantile(.x, probs = c(0.025, 0.975))
) %>%
  rename(q2.5 = `2.5%`, q97.5 = `97.5%`) %>%
  mutate(
    s_orig = as.integer(sub(".*\\[([0-9]+)\\]", "\\1", variable)),
    state_name = state_meta_north$state[match(s_orig, state_meta_north$s_orig)]
  ) %>%
  arrange(desc(median)) # Sort for ranked plotting

# Save summary table
write.csv(beta0_summary, "maepims_baseline_transmission_beta0_summary.csv", row.names = FALSE)
cat("✔ Saved 'maepims_baseline_transmission_beta0_summary.csv'\n")

# Plot 3: Ranked Bar Chart of Baseline Transmission Rates (beta_0) across Northern States
pdf("SEIRH_Spatial_Baseline_Transmission_beta0.pdf", width = 10, height = 7)

p_beta0 <- ggplot(beta0_summary, aes(x = reorder(state_name, median), y = median)) +
  geom_bar(stat = "identity", fill = "#33A02C", alpha = 0.7, width = 0.7) +
  geom_errorbar(aes(ymin = q2.5, ymax = q97.5), width = 0.3, color = "black", linewidth = 0.6) +
  coord_flip() +
  labs(
    title = "Ranked Spatial Baseline Transmission Rates (beta_0)",
    subtitle = "Posterior Median & 95% CrI across Northern States and FCT",
    x = "State / Federal Capital Territory",
    y = "Baseline Transmission Rate (beta_0)"
  ) +
  theme_bw(base_size = 11) +
  theme(
    panel.grid.minor = element_blank(),
    axis.text.y = element_text(face = "bold", size = 10)
  )

print(p_beta0)
dev.off()
cat("✔ Saved 'SEIRH_Spatial_Baseline_Transmission_beta0.pdf'\n")

cat("✔ All harmonic amplitude and baseline transmission analyses and figures successfully completed!\n")







# ==============================================================================
# COMPLETE PUBLICATION-GRADE CHOROPLETH MAP SCRIPT: NORTHERN NIGERIA & FCT
# ==============================================================================
library(tidyverse)
library(sf)
library(rnaturalearth)
library(rnaturalearthdata)
library(ggspatial)
library(patchwork)

cat("Generating fully enclosed, publication-grade spatial maps for Northern Nigeria & FCT...\n")

# 1. Prepare Northern States + FCT Subset Data
northern_fct_names <- c(
  "Adamawa", "Bauchi", "Borno", "Gombe", "Taraba", "Yobe",          # North-East
  "Jigawa", "Kaduna", "Kano", "Katsina", "Kebbi", "Sokoto", "Zamfara", # North-West
  "Benue", "Kogi", "Kwara", "Nasarawa", "Niger", "Plateau", "FCT"    # North-Central
)

beta0_vars <- sprintf("beta_0[%d]", state_meta_north$s_orig)

beta0_df <- fit$summary(variables = beta0_vars, "median") %>%
  mutate(
    s_orig = as.integer(sub(".*\\[([0-9]+)\\]", "\\1", variable)),
    state_name = state_meta_north$state[match(s_orig, state_meta_north$s_orig)],
    climate_id = stan_data$climate_zone[match(s_orig, state_meta_north$s_orig)],
    climate_zone = case_when(
      climate_id == 1 ~ "Sahel Zone",
      climate_id == 2 ~ "Sudan Savannah",
      TRUE            ~ "Guinea Savannah"
    )
  ) %>%
  rename(beta_0_median = median)

# Fetch geographic boundaries for Nigeria
nigeria_sf <- ne_states(country = "Nigeria", returnclass = "sf") %>%
  mutate(
    state_clean = case_when(
      name == "Federal Capital Territory" ~ "FCT",
      TRUE ~ name
    )
  )

north_sf <- nigeria_sf %>%
  filter(state_clean %in% northern_fct_names) %>%
  left_join(beta0_df, by = c("state_clean" = "state_name"))

# 2. Map 1: Single Overlay Map (Baseline Transmission + Climate Zone Borders)
pdf("SEIRH_Northern_Nigeria_Spatial_Beta0_Map.pdf", width = 12, height = 9)

p_map1 <- ggplot(data = north_sf) +
  geom_sf(aes(fill = beta_0_median, color = climate_zone), size = 1.4, linetype = "solid") +
  scale_fill_viridis_c(
    option = "plasma",
    name = expression(bold("Baseline Transmission (" * beta["0,s"] * ")")),
    guide = guide_colorbar(barwidth = 18, barheight = 1.0, title.position = "top", title.hjust = 0.5)
  ) +
  scale_color_manual(
    values = c("Sahel Zone" = "#D95F02", "Sudan Savannah" = "#7570B3", "Guinea Savannah" = "#1B9E77"),
    name = "Ecological Climate Zone"
  ) +
  geom_sf_text(aes(label = state_clean), size = 3.5, fontface = "bold", color = "grey10", check_overlap = TRUE) +
  annotation_scale(location = "bl", width_hint = 0.25, line_width = 1.2, text_cex = 0.9) +
  annotation_north_arrow(location = "bl", which_north = "true", 
                         pad_x = unit(0.3, "in"), pad_y = unit(0.4, "in"),
                         style = north_arrow_fancy_orienteering) +
  labs(
    title = expression(bold("Spatial Baseline Transmission Rate (" * beta["0,s"] * ") Across Northern Nigeria")),
    subtitle = "Stratified by Ecological Climate Zones with State-Level Boundaries",
    x = "Longitude",
    y = "Latitude"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(face = "bold", size = 16, hjust = 0.5, color = "grey15"),
    plot.subtitle = element_text(size = 12, hjust = 0.5, color = "grey40", face = "italic"),
    axis.title = element_text(face = "bold", size = 13, color = "grey20"),
    axis.text = element_text(size = 11, color = "grey30"),
    legend.position = "bottom",
    legend.box = "vertical",
    legend.title = element_text(face = "bold", size = 12),
    legend.text = element_text(size = 11, face = "bold"),
    panel.grid.major = element_line(color = "grey85", linewidth = 0.5, linetype = "dashed"),
    panel.background = element_rect(fill = "white", color = NA),
    plot.background = element_rect(fill = "white", color = NA),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1.2) # Encloses map in a crisp rectangle
  )

print(p_map1)
dev.off()
cat("✔ Saved enclosed map: 'SEIRH_Northern_Nigeria_Spatial_Beta0_Map.pdf'\n")

# 3. Map 2: Enhanced Dual Panel (Climate Zones vs. Baseline Transmission)
pdf("SEIRH_Northern_Nigeria_Spatial_Dual_Panel.pdf", width = 15, height = 8)

p_climate <- ggplot(data = north_sf) +
  geom_sf(aes(fill = climate_zone), color = "white", size = 0.6) +
  scale_fill_manual(
    values = c("Sahel Zone" = "#E69F00", "Sudan Savannah" = "#56B4E9", "Guinea Savannah" = "#009E73"),
    name = "Climate Zone"
  ) +
  geom_sf_text(aes(label = state_clean), size = 3.2, fontface = "bold", color = "grey10") +
  labs(title = "A. Ecological Climate Zones", x = "Longitude", y = "Latitude") +
  theme_minimal(base_size = 13) + 
  theme(
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
    axis.title = element_text(face = "bold", size = 12),
    axis.text = element_text(size = 10),
    legend.position = "bottom",
    legend.title = element_text(face = "bold", size = 11),
    legend.text = element_text(size = 10, face = "bold"),
    panel.grid.major = element_line(color = "grey90", linewidth = 0.4),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1.0) # Encloses panel A
  )

p_beta <- ggplot(data = north_sf) +
  geom_sf(aes(fill = beta_0_median), color = "white", size = 0.6) +
  scale_fill_viridis_c(
    option = "magma",
    name = expression(bold(beta["0,s"]))
  ) +
  geom_sf_text(aes(label = state_clean), size = 3.2, fontface = "bold", color = "grey90") +
  labs(title = expression(bold("B. Baseline Transmission Rate (" * beta["0,s"] * ")")), x = "Longitude", y = "Latitude") +
  theme_minimal(base_size = 13) + 
  theme(
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
    axis.title = element_text(face = "bold", size = 12),
    axis.text = element_text(size = 10),
    legend.position = "bottom",
    legend.title = element_text(face = "bold", size = 11),
    legend.text = element_text(size = 10, face = "bold"),
    panel.grid.major = element_line(color = "grey90", linewidth = 0.4),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1.0) # Encloses panel B
  )

p_combined <- p_climate + p_beta + 
  plot_annotation(
    title = "Northern Nigeria & FCT Spatial Epidemic Dynamics",
    subtitle = "Comparative Overview of Environmental Zonation and Baseline Force of Infection",
    theme = theme(
      plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
      plot.subtitle = element_text(size = 12, hjust = 0.5, face = "italic", color = "grey40")
    )
  )

print(p_combined)
dev.off()
cat("✔ Saved enclosed dual-panel PDF: 'SEIRH_Northern_Nigeria_Spatial_Dual_Panel.pdf'\n")







# ==============================================================================
# CHOROPLETH MAP: CLIMATE-ZONE FOURIER HARMONIC AMPLITUDES (A1 & A2)
# ==============================================================================
library(tidyverse)
library(sf)
library(rnaturalearth)
library(rnaturalearthdata)
library(ggspatial)
library(patchwork)

cat("Generating spatial maps for Fourier harmonic amplitudes (A1 & A2)...\n")

# 1. Prepare Northern States + FCT Data & Join Climate-Zone Amplitudes
northern_fct_names <- c(
  "Adamawa", "Bauchi", "Borno", "Gombe", "Taraba", "Yobe",          # North-East
  "Jigawa", "Kaduna", "Kano", "Katsina", "Kebbi", "Sokoto", "Zamfara", # North-West
  "Benue", "Kogi", "Kwara", "Nasarawa", "Niger", "Plateau", "FCT"    # North-Central
)

# Extract posterior medians for A1 and A2 across climate zones (C)
C <- stan_data$C
amp_vars <- c(sprintf("A1[%d]", 1:C), sprintf("A2[%d]", 1:C))

amp_df <- fit$summary(variables = amp_vars, "median") %>%
  mutate(
    parameter  = sub("\\[.*\\]", "", variable),
    climate_id = as.integer(sub(".*\\[([0-9]+)\\]", "\\1", variable))
  ) %>%
  select(climate_id, parameter, median) %>%
  pivot_wider(names_from = parameter, values_from = median) %>%
  rename(A1_median = A1, A2_median = A2)

# Map state indices to climate zones and join amplitude data
state_amp_df <- tibble(
  s_orig     = state_meta_north$s_orig,
  state_name = state_meta_north$state,
  climate_id = stan_data$climate_zone[state_meta_north$s_orig]
) %>%
  left_join(amp_df, by = "climate_id") %>%
  mutate(
    climate_zone = case_when(
      climate_id == 1 ~ "Sahel Zone",
      climate_id == 2 ~ "Sudan Savannah",
      TRUE            ~ "Guinea Savannah"
    )
  )

# Fetch geographic boundaries for Nigeria
nigeria_sf <- ne_states(country = "Nigeria", returnclass = "sf") %>%
  mutate(
    state_clean = case_when(
      name == "Federal Capital Territory" ~ "FCT",
      TRUE ~ name
    )
  )

north_amp_sf <- nigeria_sf %>%
  filter(state_clean %in% northern_fct_names) %>%
  left_join(state_amp_df, by = c("state_clean" = "state_name"))

# 2. Dual-Panel Map: Annual Amplitude (A1) vs. Semi-Annual Amplitude (A2)
pdf("SEIRH_Northern_Nigeria_Spatial_Harmonic_Amplitudes_Map.pdf", width = 16, height = 8)

p_a1 <- ggplot(data = north_amp_sf) +
  geom_sf(aes(fill = A1_median), color = "white", size = 0.6) +
  scale_fill_viridis_c(
    option = "plasma",
    name = expression(bold("Annual Amplitude (A"[1]*")"))
  ) +
  geom_sf_text(aes(label = state_clean), size = 3.2, fontface = "bold", color = "grey10") +
  annotation_scale(location = "bl", width_hint = 0.25, line_width = 1.0, text_cex = 0.8) +
  labs(
    title = expression(bold("A. Annual Harmonic Amplitude (A"[1]*")")),
    subtitle = "Primary monsoonal seasonal forcing component",
    x = "Longitude", 
    y = "Latitude"
  ) +
  theme_minimal(base_size = 13) + 
  theme(
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, face = "italic", color = "grey40"),
    axis.title = element_text(face = "bold", size = 12),
    axis.text = element_text(size = 10),
    legend.position = "bottom",
    legend.title = element_text(face = "bold", size = 11),
    legend.text = element_text(size = 10, face = "bold"),
    panel.grid.major = element_line(color = "grey90", linewidth = 0.4),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1.0)
  )

p_a2 <- ggplot(data = north_amp_sf) +
  geom_sf(aes(fill = A2_median), color = "white", size = 0.6) +
  scale_fill_viridis_c(
    option = "cividis",
    name = expression(bold("Semi-Annual Amplitude (A"[2]*")"))
  ) +
  geom_sf_text(aes(label = state_clean), size = 3.2, fontface = "bold", color = "grey10") +
  annotation_north_arrow(location = "bl", which_north = "true", 
                         pad_x = unit(0.3, "in"), pad_y = unit(0.3, "in"),
                         style = north_arrow_fancy_orienteering) +
  labs(
    title = expression(bold("B. Semi-Annual Harmonic Amplitude (A"[2]*")")),
    subtitle = "Secondary dry-season/harmattan modulation component",
    x = "Longitude", 
    y = "Latitude"
  ) +
  theme_minimal(base_size = 13) + 
  theme(
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, face = "italic", color = "grey40"),
    axis.title = element_text(face = "bold", size = 12),
    axis.text = element_text(size = 10),
    legend.position = "bottom",
    legend.title = element_text(face = "bold", size = 11),
    legend.text = element_text(size = 10, face = "bold"),
    panel.grid.major = element_line(color = "grey90", linewidth = 0.4),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1.0)
  )

p_combined_amp <- p_a1 + p_a2 + 
  plot_annotation(
    title = "Climate-Zone Fourier Harmonic Amplitudes Across Northern Nigeria",
    subtitle = "Spatial projection of posterior median values for seasonal transmission forcing",
    theme = theme(
      plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
      plot.subtitle = element_text(size = 12, hjust = 0.5, face = "italic", color = "grey40")
    )
  )

print(p_combined_amp)
dev.off()
cat("✔ Saved spatial harmonic amplitude map: 'SEIRH_Northern_Nigeria_Spatial_Harmonic_Amplitudes_Map.pdf'\n")



# ==============================================================================
# CHOROPLETH MAP: PEAK TIMING ARRIVAL ATLAS (PHASE SHIFT MAP) - RED LABELS
# ==============================================================================
library(tidyverse)
library(sf)
library(rnaturalearth)
library(rnaturalearthdata)
library(ggspatial)

cat("Calculating peak arrival weeks and generating spatial peak timing map with red labels...\n")

# 1. Prepare Northern States + FCT Data & Parameters
northern_fct_names <- c(
  "Adamawa", "Bauchi", "Borno", "Gombe", "Taraba", "Yobe",          # North-East
  "Jigawa", "Kaduna", "Kano", "Katsina", "Kebbi", "Sokoto", "Zamfara", # North-West
  "Benue", "Kogi", "Kwara", "Nasarawa", "Niger", "Plateau", "FCT"    # North-Central
)

C <- stan_data$C
weeks <- 1:52

# Extract baseline transmission (beta_0) for each state
beta0_df <- fit$summary(variables = sprintf("beta_0[%d]", state_meta_north$s_orig), "median") %>%
  mutate(
    s_orig = as.integer(sub(".*\\[([0-9]+)\\]", "\\1", variable)),
    beta_0 = median
  ) %>%
  select(s_orig, beta_0)

# Extract Fourier harmonic amplitudes (A1, A2) for each climate zone
amp_df <- fit$summary(variables = c(sprintf("A1[%d]", 1:C), sprintf("A2[%d]", 1:C)), "median") %>%
  mutate(
    parameter  = sub("\\[.*\\]", "", variable),
    climate_id = as.integer(sub(".*\\[([0-9]+)\\]", "\\1", variable))
  ) %>%
  select(climate_id, parameter, median) %>%
  pivot_wider(names_from = parameter, values_from = median)

# Combine state metadata with parameters
state_params <- tibble(
  s_orig     = state_meta_north$s_orig,
  state_name = state_meta_north$state,
  climate_id = stan_data$climate_zone[state_meta_north$s_orig]
) %>%
  left_join(beta0_df, by = "s_orig") %>%
  left_join(amp_df, by = "climate_id")

# 2. Compute Peak Arrival Week per State across the 52-week annual cycle
peak_timing_list <- list()

for (i in seq_len(nrow(state_params))) {
  row <- state_params[i,]
  s <- row$s_orig
  b0 <- row$beta_0
  a1 <- row$A1
  a2 <- row$A2
  
  twopi_52 <- 2 * pi / 52
  fourpi_52 <- 4 * pi / 52
  
  beta_t <- sapply(weeks, function(w) {
    b0 * (1.0 + a1 * cos(twopi_52 * w) + a2 * cos(fourpi_52 * w))
  })
  
  peak_week <- weeks[which.max(beta_t)]
  
  peak_timing_list[[i]] <- tibble(
    s_orig     = s,
    state_name = row$state_name,
    peak_week  = peak_week
  )
}

peak_timing_df <- bind_rows(peak_timing_list) %>%
  mutate(
    climate_zone = case_when(
      stan_data$climate_zone[s_orig] == 1 ~ "Sahel Zone",
      stan_data$climate_zone[s_orig] == 2 ~ "Sudan Savannah",
      TRUE                                ~ "Guinea Savannah"
    )
  )

# 3. Fetch Geographic Boundaries & Merge
nigeria_sf <- ne_states(country = "Nigeria", returnclass = "sf") %>%
  mutate(
    state_clean = case_when(
      name == "Federal Capital Territory" ~ "FCT",
      TRUE ~ name
    )
  )

north_peak_sf <- nigeria_sf %>%
  filter(state_clean %in% northern_fct_names) %>%
  left_join(peak_timing_df, by = c("state_clean" = "state_name"))

# 4. Generate Publication-Grade Peak Arrival Week Map with Red State Labels
pdf("SEIRH_Northern_Nigeria_Peak_Arrival_Atlas.pdf", width = 11, height = 8.5)

p_peak <- ggplot(data = north_peak_sf) +
  geom_sf(aes(fill = peak_week), color = "white", size = 0.6) +
  scale_fill_viridis_c(
    option = "turbo",
    name = expression(bold("Peak Arrival Week")),
    guide = guide_colorbar(barwidth = 18, barheight = 1.0, title.position = "top", title.hjust = 0.5)
  ) +
  # State text labels changed to bold red: color = "red"
  geom_sf_text(aes(label = state_clean), size = 3.5, fontface = "bold", color = "blue", check_overlap = TRUE) +
  annotation_scale(location = "bl", width_hint = 0.25, line_width = 1.2, text_cex = 0.9) +
  annotation_north_arrow(location = "bl", which_north = "true", 
                         pad_x = unit(0.3, "in"), pad_y = unit(0.4, "in"),
                         style = north_arrow_fancy_orienteering) +
  labs(
    title = expression(bold("Peak Timing Arrival Atlas (Phase Shift Map)")),
    subtitle = "Posterior median week of peak incidence across Northern Nigerian states",
    x = "Longitude",
    y = "Latitude"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(face = "bold", size = 16, hjust = 0.5, color = "grey15"),
    plot.subtitle = element_text(size = 12, hjust = 0.5, color = "grey40", face = "italic"),
    axis.title = element_text(face = "bold", size = 13, color = "grey20"),
    axis.text = element_text(size = 11, color = "grey30"),
    legend.position = "bottom",
    legend.box = "vertical",
    legend.title = element_text(face = "bold", size = 12),
    legend.text = element_text(size = 11, face = "bold"),
    panel.grid.major = element_line(color = "grey85", linewidth = 0.5, linetype = "dashed"),
    panel.background = element_rect(fill = "white", color = NA),
    plot.background = element_rect(fill = "white", color = NA),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1.2)
  )

print(p_peak)
dev.off()
cat("✔ Saved Peak Arrival Atlas map with red state labels: 'SEIRH_Northern_Nigeria_Peak_Arrival_Atlas.pdf'\n")




# ==============================================================================
# SUPPLEMENTARY MCMC DIAGNOSTICS & SUMMARY SCRIPT
# ==============================================================================
library(tidyverse)
library(posterior)
library(bayesplot)
library(patchwork)

cat("Generating supplementary MCMC diagnostic outputs...\n")

# 1. Parameter Grouping & Convergence Summary Table
C <- stan_data$C

# Define groups
beta0_vars <- sprintf("beta_0[%d]", state_meta_north$s_orig)
a1_vars    <- sprintf("A1[%d]", 1:C)
a2_vars    <- sprintf("A2[%d]", 1:C)

all_vars <- c(beta0_vars, a1_vars, a2_vars)

# Extract summary metrics using posterior package
diag_df <- fit$summary(variables = all_vars, "rhat", "ess_bulk", "ess_tail") %>%
  mutate(
    parameter_group = case_when(
      grepl("^beta_0", variable) ~ "Baseline Transmission (beta_0,s)",
      grepl("^A1", variable)     ~ "Annual Amplitude (A1,c)",
      grepl("^A2", variable)     ~ "Semi-Annual Amplitude (A2,c)",
      TRUE                       ~ "Other"
    )
  )

# Summarize into a clean convergence table grouped by parameter type
convergence_table <- diag_df %>%
  group_by(parameter_group) %>%
  summarise(
    `Parameter Count` = n(),
    `R-hat Range`     = sprintf("%.3f - %.3f", min(rhat, na.rm = TRUE), max(rhat, na.rm = TRUE)),
    `Min Bulk ESS`    = round(min(ess_bulk, na.rm = TRUE)),
    `Min Tail ESS`    = round(min(ess_tail, na.rm = TRUE)),
    `All R-hat <= 1.05?` = all(rhat <= 1.05, na.rm = TRUE),
    `All ESS >= 400?`   = all(ess_bulk >= 400 & ess_tail >= 400, na.rm = TRUE)
  )

print("--- Table: MCMC Convergence Summary ---")
print(convergence_table)

# Save convergence table to CSV for inclusion in manuscript supplement
write_csv(convergence_table, "SEIRH_Convergence_Summary_Table.csv")
cat("✔ Saved convergence table: 'SEIRH_Convergence_Summary_Table.csv'\n")


# 2. Joint Posterior Pair Plots for Climate-Zone Amplitudes (A1,c and A2,c)
pdf("SEIRH_Climate_Zone_Amplitude_Pairs.pdf", width = 10, height = 8)

amp_draws_df <- fit$draws(variables = c(a1_vars, a2_vars), format = "df")

p_pairs <- mcmc_pairs(
  amp_draws_df, 
  pars = names(amp_draws_df)[!names(amp_draws_df) %in% c(".chain", ".iteration", ".draw")],
  off_diag_args = list(size = 1.2, alpha = 0.3),
  diag_args = list(size = 0.8)
) + 
  ggtitle("Joint Posterior Distributions of Climate-Zone Harmonic Amplitudes")

print(p_pairs)
dev.off()
cat("✔ Saved joint posterior pair plot: 'SEIRH_Climate_Zone_Amplitude_Pairs.pdf'\n")


# 3. Compact Multi-Panel Trace Plot (1 Representative State per Climate Zone)
# Identify one representative state index for each climate zone (Zone 1, 2, 3)
rep_states <- state_meta_north %>%
  mutate(climate_id = stan_data$climate_zone[s_orig]) %>%
  group_by(climate_id) %>%
  slice(1) %>%
  ungroup()

rep_beta0_vars <- sprintf("beta_0[%d]", rep_states$s_orig)
rep_state_names <- rep_states$state

# Extract draws for representative states
trace_draws <- fit$draws(variables = rep_beta0_vars, format = "df")

# Rename columns to friendly state names for clean trace plot labeling
for(i in seq_along(rep_beta0_vars)) {
  old_col <- rep_beta0_vars[i]
  new_col <- paste0("beta_0_", rep_state_names[i])
  names(trace_draws)[names(trace_draws) == old_col] <- new_col
}

pdf("SEIRH_Representative_States_Trace_Plots.pdf", width = 12, height = 8)

p_trace <- mcmc_trace(
  trace_draws,
  pars = paste0("beta_0_", rep_state_names),
  facet_args = list(nrow = 3, labeller = label_parsed)
) +
  labs(
    title = "MCMC Trace Plots for Representative States",
    subtitle = "Sampling convergence across climate zones (Sahel, Sudan, and Guinea Savannah)",
    x = "Post-Warmup Iteration",
    y = "Parameter Value"
  ) +
  theme_minimal(base_size = 13) +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5),
    plot.subtitle = element_text(hjust = 0.5, face = "italic", color = "grey40"),
    strip.text = element_text(face = "bold", size = 12),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1)
  )

print(p_trace)
dev.off()
cat("✔ Saved representative trace plots: 'SEIRH_Representative_States_Trace_Plots.pdf'\n")






# Reliable alternative: Density overlay for climate-zone amplitudes
pdf("SEIRH_Climate_Zone_Amplitude_Densities.pdf", width = 10, height = 6)

amp_draws_df <- fit$draws(variables = c(a1_vars, a2_vars), format = "df")

p_dens <- mcmc_dens_overlay(
  amp_draws_df, 
  pars = names(amp_draws_df)[!names(amp_draws_df) %in% c(".chain", ".iteration", ".draw")]
) +
  labs(title = "Posterior Densities for Climate-Zone Harmonic Amplitudes") +
  theme_minimal(base_size = 13)

print(p_dens)
dev.off()
cat("✔ Saved density overlay plot successfully.\n")











library(posterior)

# 1. Extract summary and convergence metrics for your target parameters
exact_summary <- fit$summary(
  variables = c("gamma", "sigma", "omega", "phi_cases", "beta_0", "eta")
)

# 2. Print to console to inspect
print(exact_summary)

# 3. Save the exact summary table to a CSV file
write.csv(exact_summary, file = "SEIRH_Exact_Convergence_Summary.csv", row.names = FALSE)

cat("✔ Exact convergence summary saved to 'SEIRH_Exact_Convergence_Summary.csv'\n")