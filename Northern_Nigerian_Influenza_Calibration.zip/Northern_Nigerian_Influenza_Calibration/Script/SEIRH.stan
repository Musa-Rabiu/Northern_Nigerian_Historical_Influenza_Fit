// ============================================================================
// SEIR-H Hierarchical Spatiotemporal Epidemic Model (Fully Convergent Version)
// File: SEIRH.stan
// ============================================================================

functions {
  real partial_sum_lpmf(
    array[] int state_slice,
    int start,
    int end,
    int T,
    int C,
    array[,] int cases_mat,
    array[,] int hosp_mat,
    array[,] int deaths_mat,
    array[] int climate_zone,
    vector state_pop,
    vector hc_access,
    real gamma,
    real sigma,
    real omega,
    vector mu_beta,
    real sd_beta,
    vector beta_0_raw,
    vector A1,
    vector A2,
    matrix dev_beta,
    real sigma_beta,
    real mu_rho_logit,
    real sd_rho_logit,
    vector rho_raw,
    real alpha_hosp,
    real beta_hosp,
    real alpha_cfr,
    real beta_cfr,
    vector phi_cases,
    real phi_hosp,
    real phi_deaths,
    vector log_i0
  ) {
    real log_lik = 0.0;
    real twopi_52 = 2.0 * pi() / 52.0;
    real fourpi_52 = 4.0 * pi() / 52.0;
    real dt = 1.0 / 7.0;
    real sigma_dt = sigma * dt;
    real gamma_dt = gamma * dt;
    real omega_dt = omega * dt;

    for (i in 1:(end - start + 1)) {
      int s = state_slice[i];
      real N = state_pop[s];
      int c = climate_zone[s];

      real rho_s = inv_logit(mu_rho_logit + sd_rho_logit * rho_raw[s]);
      real beta_0_s = mu_beta[c] * exp(sd_beta * beta_0_raw[s]);
      real eta_s = inv_logit(alpha_hosp + beta_hosp * hc_access[s]);
      real CFR_s = inv_logit(alpha_cfr - beta_cfr * hc_access[s]);

      real I_curr = fmax(10.0, N * exp(log_i0[s]));
      real E_curr = 2.0 * I_curr;
      real R_curr = 0.0;
      real S_curr = fmax(1.0, N - I_curr - E_curr - R_curr);

      for (t in 1:T) {
        real harmonic_term = 1.0 + A1[c] * sin(twopi_52 * t) + A2[c] * cos(fourpi_52 * t);
        real beta_t = beta_0_s * fmax(0.05, harmonic_term) * exp(sigma_beta * dev_beta[s, t]);

        real dI_week = 0.0;

        for (day in 1:7) {
          real dE_day = fmin(S_curr, beta_t * (S_curr * I_curr) / N * dt);
          real dI_day = fmin(E_curr, sigma_dt * E_curr);
          real dR_day = fmin(I_curr, gamma_dt * I_curr);
          real dW_day = fmin(R_curr, omega_dt * R_curr);

          S_curr = fmax(0.0, S_curr - dE_day + dW_day);
          E_curr = fmax(0.0, E_curr + dE_day - dI_day);
          I_curr = fmax(0.0, I_curr + dI_day - dR_day);
          R_curr = fmax(0.0, R_curr + dR_day - dW_day);

          dI_week += dI_day;
        }

        real mu_cases_st  = fmin(1e8, fmax(1e-5, rho_s * dI_week));
        real mu_hosp_st   = fmin(1e8, fmax(1e-5, eta_s * mu_cases_st));
        real mu_deaths_st = fmin(1e8, fmax(1e-5, CFR_s * mu_hosp_st));

        log_lik += neg_binomial_2_lpmf(cases_mat[s, t] | mu_cases_st, phi_cases[s]);
        log_lik += neg_binomial_2_lpmf(hosp_mat[s, t]  | mu_hosp_st, phi_hosp);
        log_lik += neg_binomial_2_lpmf(deaths_mat[s, t]| mu_deaths_st, phi_deaths);
      }
    }
    return log_lik;
  }
}

data {
  int<lower=1> S;
  int<lower=1> T;
  int<lower=1> C;

  array[S, T] int<lower=0> cases_mat;
  array[S, T] int<lower=0> hosp_mat;
  array[S, T] int<lower=0> deaths_mat;

  array[S] int<lower=1, upper=C> climate_zone;
  vector[S] hc_access;
  vector<lower=0>[S] state_pop;
}

transformed data {
  array[S] int state_seq;
  for (s in 1:S) state_seq[s] = s;
}

parameters {
  // Informatively bounded/prior-constrained parameters to avoid gamma-beta tradeoff
  real<lower=0.5, upper=3.0> gamma;  // Recovery rate (1.4 ~ 5 days infectious period)
  real<lower=0.5, upper=5.0> sigma;  // Latent rate (3.5 ~ 2 days latent period)
  real<lower=0.001, upper=0.05> omega;

  vector<lower=0>[C] mu_beta;
  real<lower=0> sd_beta;
  vector[S] beta_0_raw;

  vector[C] A1;
  vector[C] A2;

  matrix[S, T] dev_beta;
  real<lower=0> sigma_beta;

  real mu_rho_logit;
  real<lower=0> sd_rho_logit;
  vector[S] rho_raw;

  real alpha_hosp;
  real beta_hosp;
  real alpha_cfr;
  real beta_cfr;

  vector<lower=0.01>[S] phi_cases;
  real<lower=0.01> phi_hosp;
  real<lower=0.01> phi_deaths;

  vector[S] log_i0;
}

transformed parameters {
  vector<lower=0, upper=1>[S] rho;
  vector<lower=0>[S] beta_0;
  vector<lower=0, upper=1>[S] eta;
  vector<lower=0, upper=1>[S] CFR;

  for (s in 1:S) {
    rho[s] = inv_logit(mu_rho_logit + sd_rho_logit * rho_raw[s]);
    beta_0[s] = mu_beta[climate_zone[s]] * exp(sd_beta * beta_0_raw[s]);
    eta[s] = inv_logit(alpha_hosp + beta_hosp * hc_access[s]);
    CFR[s] = inv_logit(alpha_cfr - beta_cfr * hc_access[s]);
  }
}

model {
  // Stronger informative priors on biological parameters to fix multimodality
  gamma        ~ normal(1.40, 0.05); // Fixed infectious duration centered around 5 days
  sigma        ~ normal(3.50, 0.10); // Fixed incubation duration centered around 2 days
  omega        ~ normal(0.01, 0.002);

  mu_beta      ~ normal(2.0, 0.3);   // Adjusted for gamma ~ 1.4 to keep R0 ~ 1.4-1.8
  sd_beta      ~ exponential(5);
  beta_0_raw   ~ std_normal();

  A1           ~ normal(0.0, 0.05);
  A2           ~ normal(0.0, 0.05);

  to_vector(dev_beta) ~ std_normal();
  sigma_beta   ~ exponential(10);    // Regularize weekly fluctuations

  mu_rho_logit ~ normal(-2.0, 0.2);
  sd_rho_logit ~ exponential(5);
  rho_raw      ~ std_normal();

  alpha_hosp   ~ normal(-3.5, 0.2);
  beta_hosp    ~ normal(0.0, 0.2);
  alpha_cfr    ~ normal(-2.0, 0.2);
  beta_cfr     ~ normal(0.0, 0.2);

  phi_cases    ~ gamma(3, 0.1);
  phi_hosp     ~ gamma(3, 0.1);
  phi_deaths   ~ gamma(3, 0.1);

  log_i0       ~ normal(-5.5, 0.3);

  target += reduce_sum(
    partial_sum_lpmf, state_seq, 1,
    T, C, cases_mat, hosp_mat, deaths_mat, climate_zone,
    state_pop, hc_access, gamma, sigma, omega, mu_beta,
    sd_beta, beta_0_raw, A1, A2, dev_beta, sigma_beta,
    mu_rho_logit, sd_rho_logit, rho_raw, alpha_hosp,
    beta_hosp, alpha_cfr, beta_cfr, phi_cases, phi_hosp,
    phi_deaths, log_i0
  );
}

generated quantities {
  matrix[S, T] mu_cases;
  matrix[S, T] mu_hosp;
  matrix[S, T] mu_deaths;

  array[S, T] int cases_rep;
  array[S, T] int hosp_rep;
  array[S, T] int deaths_rep;

  real twopi_52 = 2.0 * pi() / 52.0;
  real fourpi_52 = 4.0 * pi() / 52.0;
  real dt = 1.0 / 7.0;
  real sigma_dt = sigma * dt;
  real gamma_dt = gamma * dt;
  real omega_dt = omega * dt;

  for (s in 1:S) {
    real N = state_pop[s];
    int c = climate_zone[s];

    real I_curr = fmax(10.0, N * exp(log_i0[s]));
    real E_curr = 2.0 * I_curr;
    real R_curr = 0.0;
    real S_curr = fmax(1.0, N - I_curr - E_curr - R_curr);

    for (t in 1:T) {
      real harmonic_term = 1.0 + A1[c] * sin(twopi_52 * t) + A2[c] * cos(fourpi_52 * t);
      real beta_t = beta_0[s] * fmax(0.05, harmonic_term) * exp(sigma_beta * dev_beta[s, t]);

      real dI_week = 0.0;

      for (day in 1:7) {
        real dE_day = fmin(S_curr, beta_t * (S_curr * I_curr) / N * dt);
        real dI_day = fmin(E_curr, sigma_dt * E_curr);
        real dR_day = fmin(I_curr, gamma_dt * I_curr);
        real dW_day = fmin(R_curr, omega_dt * R_curr);

        S_curr = fmax(0.0, S_curr - dE_day + dW_day);
        E_curr = fmax(0.0, E_curr + dE_day - dI_day);
        I_curr = fmax(0.0, I_curr + dI_day - dR_day);
        R_curr = fmax(0.0, R_curr + dR_day - dW_day);

        dI_week += dI_day;
      }

      mu_cases[s, t]  = fmin(1e8, fmax(1e-5, rho[s] * dI_week));
      mu_hosp[s, t]   = fmin(1e8, fmax(1e-5, eta[s] * mu_cases[s, t]));
      mu_deaths[s, t] = fmin(1e8, fmax(1e-5, CFR[s] * mu_hosp[s, t]));

      cases_rep[s, t]  = neg_binomial_2_rng(mu_cases[s, t], phi_cases[s]);
      hosp_rep[s, t]   = neg_binomial_2_rng(mu_hosp[s, t], phi_hosp);
      deaths_rep[s, t] = neg_binomial_2_rng(mu_deaths[s, t], phi_deaths);
    }
  }
}